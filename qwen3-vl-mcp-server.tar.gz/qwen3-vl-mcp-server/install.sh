#!/bin/bash

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Qwen3-VL MCP Server Installation ===${NC}"

# Проверка Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js is not installed${NC}"
    echo "Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}Error: Node.js version 18+ is required${NC}"
    echo "Current version: $(node -v)"
    exit 1
fi

echo -e "${GREEN}✓ Node.js $(node -v) detected${NC}"

# Проверка npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}Error: npm is not installed${NC}"
    exit 1
fi

echo -e "${GREEN}✓ npm $(npm -v) detected${NC}"

# Установка зависимостей
echo -e "${YELLOW}Installing dependencies...${NC}"
npm install

if [ $? -ne 0 ]; then
    echo -e "${RED}Error: Failed to install dependencies${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Dependencies installed${NC}"

# Сборка проекта
echo -e "${YELLOW}Building project...${NC}"
npm run build

if [ $? -ne 0 ]; then
    echo -e "${RED}Error: Failed to build project${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Project built successfully${NC}"

# Получение абсолютного пути
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Проверка переменных окружения
echo -e "${YELLOW}Checking environment variables...${NC}"

if [ -z "$QWEN_VL_API_URL" ]; then
    echo -e "${YELLOW}QWEN_VL_API_URL is not set. Using default: http://localhost:8000${NC}"
    export QWEN_VL_API_URL="http://localhost:8000"
fi

echo -e "${GREEN}✓ API URL: $QWEN_VL_API_URL${NC}"

# Проверка здоровья API
echo -e "${YELLOW}Checking Qwen3-VL API health...${NC}"
if command -v curl &> /dev/null; then
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$QWEN_VL_API_URL/api/health" || echo "000")
    if [ "$HTTP_CODE" -eq 200 ]; then
        echo -e "${GREEN}✓ API server is healthy${NC}"
    else
        echo -e "${RED}⚠ Warning: API server is not responding (HTTP $HTTP_CODE)${NC}"
        echo -e "${YELLOW}Please make sure the Qwen3-VL API server is running at $QWEN_VL_API_URL${NC}"
    fi
else
    echo -e "${YELLOW}⚠ curl not found, skipping API health check${NC}"
fi

# Создание конфигурации для Claude Code
echo ""
echo -e "${GREEN}=== Configuration for Claude Code ===${NC}"
echo ""
echo "Add this to your MCP configuration file:"
echo ""
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo -e "${YELLOW}macOS:${NC} ~/.config/claude/mcp_config.json"
elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    echo -e "${YELLOW}Windows:${NC} %APPDATA%\\Claude\\mcp_config.json"
else
    echo -e "${YELLOW}Linux:${NC} ~/.config/claude/mcp_config.json"
fi
echo ""
echo "{"
echo "  \"mcpServers\": {"
echo "    \"qwen3-vl\": {"
echo "      \"command\": \"node\","
echo "      \"args\": [\"$SCRIPT_DIR/dist/index.js\"],"
echo "      \"env\": {"
echo "        \"QWEN_VL_API_URL\": \"$QWEN_VL_API_URL\","
echo "        \"QWEN_VL_API_TIMEOUT\": \"120000\""
echo "      }"
echo "    }"
echo "  }"
echo "}"
echo ""
echo -e "${GREEN}=== Installation Complete ===${NC}"
echo ""
echo "Next steps:"
echo "1. Make sure your Qwen3-VL API server is running"
echo "2. Add the configuration above to your Claude Code MCP config"
echo "3. Restart Claude Code"
echo "4. Test with: 'List available MCP tools'"
echo ""
