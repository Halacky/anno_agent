#!/usr/bin/env node

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from "@modelcontextprotocol/sdk/types.js";
import axios, { AxiosInstance } from "axios";
import FormData from "form-data";
import { readFileSync } from "fs";

// Конфигурация
const API_BASE_URL = process.env.QWEN_VL_API_URL || "http://localhost:8000";
const API_TIMEOUT = parseInt(process.env.QWEN_VL_API_TIMEOUT || "120000");

// Типы для различных задач
interface GroundingRequest {
  image_url?: string;
  image_path?: string;
  categories: string[];
  output_format?: "json" | "text";
  include_attributes?: boolean;
}

interface SpatialRequest {
  image_url?: string;
  image_path?: string;
  query: string;
  output_format?: "json" | "text";
}

interface VideoRequest {
  video_url?: string;
  video_path?: string;
  prompt: string;
  max_frames?: number;
  sample_fps?: number;
}

interface DescriptionRequest {
  image_url?: string;
  image_path?: string;
  detail_level?: "basic" | "detailed" | "comprehensive";
}

interface DocumentParsingRequest {
  image_url?: string;
  image_path?: string;
  output_format?: "html" | "markdown" | "qwenvl_html" | "qwenvl_markdown";
}

interface OCRRequest {
  image_url?: string;
  image_path?: string;
  granularity?: "word" | "line" | "paragraph";
  include_bbox?: boolean;
  output_format?: "json" | "text";
}

interface ImageComparisonRequest {
  image_urls?: string[];
  image_paths?: string[];
  comparison_type?: "differences" | "changes" | "similarities";
  output_format?: "json" | "text";
  prompt?: string;
}

// Клиент для API
class Qwen3VLClient {
  private client: AxiosInstance;

  constructor(baseURL: string, timeout: number) {
    this.client = axios.create({
      baseURL,
      timeout,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  // 2D Grounding - обнаружение объектов
  async grounding2D(params: GroundingRequest): Promise<any> {
    const response = await this.client.post("/api/v1/grounding/2d", params);
    return response.data;
  }

  // Spatial Understanding - пространственное понимание
  async spatialUnderstanding(params: SpatialRequest): Promise<any> {
    const response = await this.client.post("/api/v1/spatial/understanding", params);
    return response.data;
  }

  // Video Understanding - анализ видео
  async videoUnderstanding(params: VideoRequest): Promise<any> {
    const response = await this.client.post("/api/v1/video/understanding", params);
    return response.data;
  }

  // Image Description - описание изображений
  async imageDescription(params: DescriptionRequest): Promise<any> {
    const response = await this.client.post("/api/v1/image/description", params);
    return response.data;
  }

  // Document Parsing - парсинг документов
  async documentParsing(params: DocumentParsingRequest): Promise<any> {
    const response = await this.client.post("/api/v1/document/parsing", params);
    return response.data;
  }

  // Document OCR
  async documentOCR(params: OCRRequest): Promise<any> {
    const response = await this.client.post("/api/v1/ocr/document", params);
    return response.data;
  }

  // Wild Image OCR - OCR на естественных изображениях
  async wildImageOCR(params: OCRRequest): Promise<any> {
    const response = await this.client.post("/api/v1/ocr/wild", params);
    return response.data;
  }

  // Image Comparison - сравнение изображений
  async imageComparison(params: ImageComparisonRequest): Promise<any> {
    const response = await this.client.post("/api/v1/image/comparison", params);
    return response.data;
  }

  // Health Check
  async healthCheck(): Promise<any> {
    const response = await this.client.get("/api/health");
    return response.data;
  }
}

// Определение инструментов MCP
const TOOLS: Tool[] = [
  {
    name: "qwen_vl_grounding_2d",
    description: "Detect and locate objects in images. Returns bounding boxes and object categories.",
    inputSchema: {
      type: "object",
      properties: {
        image_url: {
          type: "string",
          description: "URL of the image to analyze",
        },
        image_path: {
          type: "string",
          description: "Local path to the image file",
        },
        categories: {
          type: "array",
          items: { type: "string" },
          description: "List of object categories to detect (e.g., ['person', 'car', 'bicycle'])",
        },
        output_format: {
          type: "string",
          enum: ["json", "text"],
          description: "Output format (default: json)",
        },
        include_attributes: {
          type: "boolean",
          description: "Include object attributes in response",
        },
      },
      required: ["categories"],
    },
  },
  {
    name: "qwen_vl_spatial_understanding",
    description: "Understand spatial relationships and answer questions about object positions in images.",
    inputSchema: {
      type: "object",
      properties: {
        image_url: {
          type: "string",
          description: "URL of the image to analyze",
        },
        image_path: {
          type: "string",
          description: "Local path to the image file",
        },
        query: {
          type: "string",
          description: "Question about spatial relationships (e.g., 'What objects are on the table?')",
        },
        output_format: {
          type: "string",
          enum: ["json", "text"],
          description: "Output format (default: json)",
        },
      },
      required: ["query"],
    },
  },
  {
    name: "qwen_vl_video_understanding",
    description: "Analyze videos and understand temporal events and actions.",
    inputSchema: {
      type: "object",
      properties: {
        video_url: {
          type: "string",
          description: "URL of the video to analyze",
        },
        video_path: {
          type: "string",
          description: "Local path to the video file",
        },
        prompt: {
          type: "string",
          description: "Question or instruction for video analysis",
        },
        max_frames: {
          type: "number",
          description: "Maximum number of frames to process (default: 128)",
        },
        sample_fps: {
          type: "number",
          description: "Frames per second to sample (default: 1.0)",
        },
      },
      required: ["prompt"],
    },
  },
  {
    name: "qwen_vl_image_description",
    description: "Generate detailed descriptions of images.",
    inputSchema: {
      type: "object",
      properties: {
        image_url: {
          type: "string",
          description: "URL of the image to describe",
        },
        image_path: {
          type: "string",
          description: "Local path to the image file",
        },
        detail_level: {
          type: "string",
          enum: ["basic", "detailed", "comprehensive"],
          description: "Level of detail in description (default: detailed)",
        },
      },
      required: [],
    },
  },
  {
    name: "qwen_vl_document_parsing",
    description: "Parse documents and convert them to various formats (HTML, Markdown, JSON).",
    inputSchema: {
      type: "object",
      properties: {
        image_url: {
          type: "string",
          description: "URL of the document image",
        },
        image_path: {
          type: "string",
          description: "Local path to the document image",
        },
        output_format: {
          type: "string",
          enum: ["html", "markdown", "qwenvl_html", "qwenvl_markdown"],
          description: "Output format for parsed document (default: qwenvl_html)",
        },
      },
      required: [],
    },
  },
  {
    name: "qwen_vl_document_ocr",
    description: "Perform OCR on structured documents with layout preservation.",
    inputSchema: {
      type: "object",
      properties: {
        image_url: {
          type: "string",
          description: "URL of the document image",
        },
        image_path: {
          type: "string",
          description: "Local path to the document image",
        },
        granularity: {
          type: "string",
          enum: ["word", "line", "paragraph"],
          description: "Text extraction granularity (default: line)",
        },
        include_bbox: {
          type: "boolean",
          description: "Include bounding boxes for text regions",
        },
        output_format: {
          type: "string",
          enum: ["json", "text"],
          description: "Output format (default: json)",
        },
      },
      required: [],
    },
  },
  {
    name: "qwen_vl_wild_image_ocr",
    description: "Extract text from natural images (street signs, storefronts, etc.).",
    inputSchema: {
      type: "object",
      properties: {
        image_url: {
          type: "string",
          description: "URL of the image",
        },
        image_path: {
          type: "string",
          description: "Local path to the image",
        },
        include_bbox: {
          type: "boolean",
          description: "Include bounding boxes for detected text",
        },
      },
      required: [],
    },
  },
  {
    name: "qwen_vl_image_comparison",
    description: "Compare multiple images (2-4) to find differences, changes, or similarities.",
    inputSchema: {
      type: "object",
      properties: {
        image_urls: {
          type: "array",
          items: { type: "string" },
          description: "URLs of images to compare (2-4 images)",
        },
        image_paths: {
          type: "array",
          items: { type: "string" },
          description: "Local paths to images (2-4 images)",
        },
        comparison_type: {
          type: "string",
          enum: ["differences", "changes", "similarities"],
          description: "Type of comparison (default: differences)",
        },
        output_format: {
          type: "string",
          enum: ["json", "text"],
          description: "Output format (default: json)",
        },
        prompt: {
          type: "string",
          description: "Optional custom prompt for comparison",
        },
      },
      required: [],
    },
  },
  {
    name: "qwen_vl_health_check",
    description: "Check if the Qwen3-VL API server is healthy and ready.",
    inputSchema: {
      type: "object",
      properties: {},
    },
  },
];

// MCP сервер
class Qwen3VLMCPServer {
  private server: Server;
  private client: Qwen3VLClient;

  constructor() {
    this.server = new Server(
      {
        name: "qwen3-vl-mcp-server",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.client = new Qwen3VLClient(API_BASE_URL, API_TIMEOUT);
    this.setupHandlers();
  }

  private setupHandlers(): void {
    // Список инструментов
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: TOOLS,
    }));

    // Вызов инструментов
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      try {
        switch (name) {
          case "qwen_vl_grounding_2d":
            return await this.handleGrounding2D(args as GroundingRequest);

          case "qwen_vl_spatial_understanding":
            return await this.handleSpatialUnderstanding(args as SpatialRequest);

          case "qwen_vl_video_understanding":
            return await this.handleVideoUnderstanding(args as VideoRequest);

          case "qwen_vl_image_description":
            return await this.handleImageDescription(args as DescriptionRequest);

          case "qwen_vl_document_parsing":
            return await this.handleDocumentParsing(args as DocumentParsingRequest);

          case "qwen_vl_document_ocr":
            return await this.handleDocumentOCR(args as OCRRequest);

          case "qwen_vl_wild_image_ocr":
            return await this.handleWildImageOCR(args as OCRRequest);

          case "qwen_vl_image_comparison":
            return await this.handleImageComparison(args as ImageComparisonRequest);

          case "qwen_vl_health_check":
            return await this.handleHealthCheck();

          default:
            throw new Error(`Unknown tool: ${name}`);
        }
      } catch (error: any) {
        return {
          content: [
            {
              type: "text",
              text: `Error: ${error.message}\n${error.response?.data ? JSON.stringify(error.response.data, null, 2) : ""}`,
            },
          ],
          isError: true,
        };
      }
    });
  }

  private async handleGrounding2D(args: GroundingRequest) {
    const result = await this.client.grounding2D(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleSpatialUnderstanding(args: SpatialRequest) {
    const result = await this.client.spatialUnderstanding(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleVideoUnderstanding(args: VideoRequest) {
    const result = await this.client.videoUnderstanding(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleImageDescription(args: DescriptionRequest) {
    const result = await this.client.imageDescription(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleDocumentParsing(args: DocumentParsingRequest) {
    const result = await this.client.documentParsing(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleDocumentOCR(args: OCRRequest) {
    const result = await this.client.documentOCR(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleWildImageOCR(args: OCRRequest) {
    const result = await this.client.wildImageOCR(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleImageComparison(args: ImageComparisonRequest) {
    const result = await this.client.imageComparison(args);
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  private async handleHealthCheck() {
    const result = await this.client.healthCheck();
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  }

  async run(): Promise<void> {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error("Qwen3-VL MCP Server running on stdio");
  }
}

// Запуск сервера
const server = new Qwen3VLMCPServer();
server.run().catch(console.error);
