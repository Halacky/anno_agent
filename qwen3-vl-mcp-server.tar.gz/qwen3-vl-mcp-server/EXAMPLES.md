# Примеры использования Qwen3-VL MCP Server

## Базовые примеры

### 1. Проверка здоровья сервера

```
Use qwen_vl_health_check
```

Ожидаемый ответ:
```json
{
  "status": "healthy",
  "model_loaded": true,
  "version": "1.0.0"
}
```

### 2. Простое описание изображения

```
Use qwen_vl_image_description with:
- image_url: "https://example.com/photo.jpg"
- detail_level: "detailed"
```

### 3. Обнаружение объектов

```
Use qwen_vl_grounding_2d with:
- image_url: "https://example.com/street.jpg"
- categories: ["person", "car", "bicycle", "traffic_light"]
- include_attributes: true
```

## Продвинутые сценарии

### Анализ документа

**Шаг 1: OCR документа**
```
Use qwen_vl_document_ocr with:
- image_path: "/path/to/invoice.jpg"
- granularity: "line"
- include_bbox: true
- output_format: "json"
```

**Шаг 2: Парсинг в структурированный формат**
```
Use qwen_vl_document_parsing with:
- image_path: "/path/to/invoice.jpg"
- output_format: "qwenvl_html"
```

### Сравнение версий документа

```
Use qwen_vl_image_comparison with:
- image_paths: ["/path/to/version1.pdf", "/path/to/version2.pdf"]
- comparison_type: "differences"
- prompt: "Identify all changes between these two document versions"
```

### Анализ видео презентации

```
Use qwen_vl_video_understanding with:
- video_path: "/path/to/presentation.mp4"
- prompt: "Summarize the key points presented in each slide"
- max_frames: 256
- sample_fps: 0.5
```

### Извлечение текста с вывесок

```
Use qwen_vl_wild_image_ocr with:
- image_url: "https://example.com/storefront.jpg"
- include_bbox: true
```

### Пространственный анализ интерьера

```
Use qwen_vl_spatial_understanding with:
- image_path: "/path/to/room.jpg"
- query: "List all furniture items and their positions relative to the walls"
```

## Интеграция с другими инструментами

### Пайплайн обработки документов

```python
# Пример Python скрипта, использующего MCP сервер через Claude Code

# 1. Загрузить документ
document_path = "/path/to/contract.pdf"

# 2. Выполнить OCR
Use qwen_vl_document_ocr with document

# 3. Извлечь ключевые поля
Use qwen_vl_spatial_understanding to find:
- Contract date
- Party names
- Signature locations

# 4. Парсить в структурированный формат
Use qwen_vl_document_parsing to convert to JSON

# 5. Валидировать данные
Validate extracted fields against expected schema
```

### Мониторинг изменений на веб-странице

```bash
#!/bin/bash

# Сделать скриншот страницы
screenshot_url="https://example.com/page-screenshot.png"

# Сравнить с предыдущей версией
Use qwen_vl_image_comparison with:
- image_urls: ["$previous_screenshot", "$current_screenshot"]
- comparison_type: "differences"
- prompt: "Highlight any UI changes or new content"
```

### Автоматическая категоризация изображений

```javascript
// Node.js скрипт для batch обработки

const images = [
  "product1.jpg",
  "product2.jpg",
  "product3.jpg"
];

for (const image of images) {
  // Описать изображение
  Use qwen_vl_image_description with image
  
  // Обнаружить объекты
  Use qwen_vl_grounding_2d with:
    - categories: ["product", "packaging", "label"]
  
  // Извлечь текст с этикеток
  Use qwen_vl_wild_image_ocr with image
  
  // Категоризировать на основе результатов
}
```

## Работа с локальными файлами

### Batch обработка изображений в папке

```
For each image in /path/to/images/:
  Use qwen_vl_image_description to describe the image
  Use qwen_vl_grounding_2d to detect objects
  Save results to /path/to/results/
```

### Извлечение данных из сканов документов

```
For each scan in /path/to/scans/:
  Use qwen_vl_document_ocr with:
    - granularity: "paragraph"
    - include_bbox: true
  
  Use qwen_vl_document_parsing with:
    - output_format: "markdown"
  
  Save markdown to /path/to/extracted/
```

## Продвинутые промпты

### Детальный анализ изображения

```
Use qwen_vl_spatial_understanding with:
- image_url: "https://example.com/scene.jpg"
- query: "Provide a detailed analysis including:
  1. Main objects and their positions
  2. Spatial relationships between objects
  3. Estimated distances and sizes
  4. Environmental context (indoor/outdoor, lighting, weather)
  5. Any text visible in the scene"
```

### Сравнение дизайна UI

```
Use qwen_vl_image_comparison with:
- image_urls: ["design_v1.png", "design_v2.png", "design_v3.png"]
- comparison_type: "differences"
- prompt: "Compare these UI designs and identify:
  1. Layout changes
  2. Color scheme variations
  3. Typography differences
  4. Component additions/removals
  5. Spacing and alignment modifications"
```

### Анализ медицинских изображений

**Примечание:** Используйте только для образовательных целей, не для медицинской диагностики.

```
Use qwen_vl_grounding_2d with:
- image_path: "/path/to/xray.jpg"
- categories: ["bone", "fracture", "anomaly"]
- include_attributes: true
```

## Обработка ошибок

### Проверка доступности API перед запросом

```javascript
// Сначала проверить здоровье
const health = await qwen_vl_health_check();

if (health.status === "healthy") {
  // Выполнить основной запрос
  const result = await qwen_vl_image_description({
    image_url: "https://example.com/image.jpg"
  });
} else {
  console.error("API server is not healthy");
}
```

### Retry логика для больших файлов

```python
import time

max_retries = 3
retry_delay = 5  # секунд

for attempt in range(max_retries):
    try:
        result = Use qwen_vl_video_understanding with large_video
        break
    except TimeoutError:
        if attempt < max_retries - 1:
            print(f"Timeout, retrying in {retry_delay} seconds...")
            time.sleep(retry_delay)
        else:
            raise
```

## Оптимизация производительности

### Уменьшение размера видео для быстрой обработки

```
Use qwen_vl_video_understanding with:
- video_path: "/path/to/long_video.mp4"
- max_frames: 64  # Уменьшить количество кадров
- sample_fps: 0.5  # Снизить частоту сэмплирования
```

### Параллельная обработка множества изображений

```javascript
// Обработать несколько изображений параллельно
const images = ["img1.jpg", "img2.jpg", "img3.jpg"];

const promises = images.map(img => 
  qwen_vl_image_description({
    image_path: img,
    detail_level: "basic"  // Быстрее, чем comprehensive
  })
);

const results = await Promise.all(promises);
```

## Интеграция с CI/CD

### Автоматическое тестирование UI

```yaml
# .github/workflows/ui-test.yml
name: UI Visual Test

on: [push]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Take screenshot
        run: ./take-screenshot.sh
      
      - name: Compare with baseline
        run: |
          Use qwen_vl_image_comparison with:
            - image_paths: ["baseline.png", "current.png"]
            - comparison_type: "differences"
      
      - name: Fail if differences found
        run: ./check-differences.sh
```

## Советы и лучшие практики

1. **Выбор формата изображения:**
   - Используйте `image_url` для удаленных изображений
   - Используйте `image_path` для локальных файлов

2. **Оптимизация промптов:**
   - Будьте конкретны в запросах
   - Используйте структурированные промпты для лучших результатов
   - Указывайте желаемый формат вывода

3. **Обработка больших файлов:**
   - Увеличьте timeout для видео и больших изображений
   - Используйте меньшие значения `max_frames` для быстрой обработки
   - Рассмотрите pre-processing (сжатие) перед отправкой

4. **Безопасность:**
   - Не передавайте чувствительные данные через публичные URL
   - Используйте `image_path` для конфиденциальных документов
   - Очищайте временные файлы после обработки

5. **Мониторинг:**
   - Регулярно проверяйте `qwen_vl_health_check`
   - Логируйте все запросы для отладки
   - Настройте алерты при частых ошибках
