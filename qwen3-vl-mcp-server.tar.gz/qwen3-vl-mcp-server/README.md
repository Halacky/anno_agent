# Qwen3-VL MCP Server

MCP (Model Context Protocol) сервер для интеграции Qwen3-VL API с Claude Code и другими MCP-совместимыми клиентами.

## Возможности

Этот MCP сервер предоставляет доступ ко всем возможностям Qwen3-VL API:

1. **2D Grounding** - Обнаружение и локализация объектов на изображениях
2. **Spatial Understanding** - Пространственное понимание и рассуждение
3. **Video Understanding** - Анализ видео и понимание временных событий
4. **Image Description** - Детальное описание изображений
5. **Document Parsing** - Парсинг документов в различные форматы
6. **Document OCR** - Распознавание текста в документах
7. **Wild Image OCR** - Распознавание текста на естественных изображениях
8. **Image Comparison** - Сравнение нескольких изображений

## Установка

### Требования

- Node.js 18+ 
- npm или yarn
- Запущенный Qwen3-VL API сервер (см. https://github.com/rpol-recart/qwen3-vl-inference)

### Шаги установки

1. Клонируйте или скопируйте этот репозиторий:

```bash
cd qwen3-vl-mcp-server
```

2. Установите зависимости:

```bash
npm install
```

3. Соберите проект:

```bash
npm run build
```

## Конфигурация

Настройте переменные окружения:

```bash
# URL вашего Qwen3-VL API сервера
export QWEN_VL_API_URL=http://localhost:8000

# Timeout для API запросов (в миллисекундах)
export QWEN_VL_API_TIMEOUT=120000
```

## Интеграция с Claude Code

### Автоматическая установка (рекомендуется)

1. Запустите Claude Code:

```bash
claude
```

2. В Claude Code введите:

```
/mcp install /path/to/qwen3-vl-mcp-server
```

### Ручная конфигурация

Отредактируйте конфигурационный файл MCP:

**macOS/Linux:** `~/.config/claude/mcp_config.json`
**Windows:** `%APPDATA%\Claude\mcp_config.json`

Добавьте сервер в секцию `mcpServers`:

```json
{
  "mcpServers": {
    "qwen3-vl": {
      "command": "node",
      "args": ["/path/to/qwen3-vl-mcp-server/dist/index.js"],
      "env": {
        "QWEN_VL_API_URL": "http://localhost:8000",
        "QWEN_VL_API_TIMEOUT": "120000"
      }
    }
  }
}
```

### Проверка установки

После настройки перезапустите Claude Code и проверьте доступность инструментов:

```
List available MCP tools
```

Вы должны увидеть следующие инструменты:
- `qwen_vl_grounding_2d`
- `qwen_vl_spatial_understanding`
- `qwen_vl_video_understanding`
- `qwen_vl_image_description`
- `qwen_vl_document_parsing`
- `qwen_vl_document_ocr`
- `qwen_vl_wild_image_ocr`
- `qwen_vl_image_comparison`
- `qwen_vl_health_check`

## Использование в Claude Code

### Пример 1: Описание изображения

```
Use qwen_vl_image_description to describe the image at https://example.com/photo.jpg with detailed level
```

### Пример 2: Обнаружение объектов

```
Use qwen_vl_grounding_2d to detect person, car, and bicycle in the image at https://example.com/street.jpg
```

### Пример 3: Извлечение текста из документа

```
Use qwen_vl_document_ocr to extract text from the document at /path/to/document.jpg with line granularity
```

### Пример 4: Анализ видео

```
Use qwen_vl_video_understanding to analyze the video at https://example.com/video.mp4 and describe the main events
```

### Пример 5: Сравнение изображений

```
Use qwen_vl_image_comparison to find differences between these images:
- https://example.com/before.jpg
- https://example.com/after.jpg
```

### Пример 6: Пространственное понимание

```
Use qwen_vl_spatial_understanding to answer "What objects are on the table?" for the image at https://example.com/room.jpg
```

## API Reference

### qwen_vl_grounding_2d

Обнаруживает объекты на изображениях.

**Параметры:**
- `image_url` (string, optional): URL изображения
- `image_path` (string, optional): Локальный путь к изображению
- `categories` (array, required): Список категорий для поиска
- `output_format` (string, optional): Формат вывода (json | text)
- `include_attributes` (boolean, optional): Включить атрибуты объектов

**Пример:**
```json
{
  "image_url": "https://example.com/image.jpg",
  "categories": ["person", "car", "bicycle"],
  "output_format": "json",
  "include_attributes": true
}
```

### qwen_vl_spatial_understanding

Отвечает на вопросы о пространственных отношениях объектов.

**Параметры:**
- `image_url` (string, optional): URL изображения
- `image_path` (string, optional): Локальный путь к изображению
- `query` (string, required): Вопрос о пространственных отношениях
- `output_format` (string, optional): Формат вывода (json | text)

**Пример:**
```json
{
  "image_url": "https://example.com/room.jpg",
  "query": "What objects are on the table?",
  "output_format": "json"
}
```

### qwen_vl_video_understanding

Анализирует видео.

**Параметры:**
- `video_url` (string, optional): URL видео
- `video_path` (string, optional): Локальный путь к видео
- `prompt` (string, required): Инструкция для анализа
- `max_frames` (number, optional): Максимум кадров для обработки
- `sample_fps` (number, optional): FPS для сэмплирования

**Пример:**
```json
{
  "video_url": "https://example.com/video.mp4",
  "prompt": "Describe the main events in this video",
  "max_frames": 128,
  "sample_fps": 1.0
}
```

### qwen_vl_image_description

Генерирует описания изображений.

**Параметры:**
- `image_url` (string, optional): URL изображения
- `image_path` (string, optional): Локальный путь к изображению
- `detail_level` (string, optional): Уровень детализации (basic | detailed | comprehensive)

**Пример:**
```json
{
  "image_url": "https://example.com/image.jpg",
  "detail_level": "comprehensive"
}
```

### qwen_vl_document_parsing

Парсит документы в различные форматы.

**Параметры:**
- `image_url` (string, optional): URL изображения документа
- `image_path` (string, optional): Локальный путь к изображению документа
- `output_format` (string, optional): Формат вывода (html | markdown | qwenvl_html | qwenvl_markdown)

**Пример:**
```json
{
  "image_url": "https://example.com/document.jpg",
  "output_format": "qwenvl_html"
}
```

### qwen_vl_document_ocr

Выполняет OCR на структурированных документах.

**Параметры:**
- `image_url` (string, optional): URL изображения документа
- `image_path` (string, optional): Локальный путь к изображению документа
- `granularity` (string, optional): Гранулярность (word | line | paragraph)
- `include_bbox` (boolean, optional): Включить bounding boxes
- `output_format` (string, optional): Формат вывода (json | text)

**Пример:**
```json
{
  "image_url": "https://example.com/document.jpg",
  "granularity": "line",
  "include_bbox": true,
  "output_format": "json"
}
```

### qwen_vl_wild_image_ocr

Извлекает текст из естественных изображений.

**Параметры:**
- `image_url` (string, optional): URL изображения
- `image_path` (string, optional): Локальный путь к изображению
- `include_bbox` (boolean, optional): Включить bounding boxes

**Пример:**
```json
{
  "image_url": "https://example.com/street_sign.jpg",
  "include_bbox": true
}
```

### qwen_vl_image_comparison

Сравнивает несколько изображений.

**Параметры:**
- `image_urls` (array, optional): URLs изображений (2-4)
- `image_paths` (array, optional): Локальные пути к изображениям (2-4)
- `comparison_type` (string, optional): Тип сравнения (differences | changes | similarities)
- `output_format` (string, optional): Формат вывода (json | text)
- `prompt` (string, optional): Кастомный промпт

**Пример:**
```json
{
  "image_urls": [
    "https://example.com/image1.jpg",
    "https://example.com/image2.jpg"
  ],
  "comparison_type": "differences",
  "output_format": "json"
}
```

### qwen_vl_health_check

Проверяет здоровье API сервера.

**Параметры:** Нет

**Пример:**
```json
{}
```

## Разработка

### Структура проекта

```
qwen3-vl-mcp-server/
├── src/
│   └── index.ts          # Главный файл сервера
├── dist/                 # Скомпилированный код (генерируется)
├── package.json
├── tsconfig.json
└── README.md
```

### Сборка

```bash
npm run build
```

### Watch режим для разработки

```bash
npm run watch
```

### Тестирование локально

Запустите сервер напрямую:

```bash
node dist/index.js
```

Затем отправьте JSON-RPC запросы через stdin/stdout для тестирования.

## Устранение неполадок

### Сервер не запускается

1. Проверьте, что API сервер Qwen3-VL запущен:
   ```bash
   curl http://localhost:8000/api/health
   ```

2. Проверьте переменные окружения:
   ```bash
   echo $QWEN_VL_API_URL
   ```

3. Проверьте логи Claude Code в режиме отладки

### Инструменты не видны в Claude Code

1. Перезапустите Claude Code
2. Проверьте конфигурацию MCP в `mcp_config.json`
3. Убедитесь, что путь к `dist/index.js` правильный

### Timeout ошибки

Увеличьте `QWEN_VL_API_TIMEOUT` для больших изображений или видео:

```bash
export QWEN_VL_API_TIMEOUT=300000  # 5 минут
```

## Лицензия

MIT

## Вклад

Приветствуются pull requests и issues!

## Связанные проекты

- [Qwen3-VL Inference Server](https://github.com/rpol-recart/qwen3-vl-inference)
- [Model Context Protocol](https://github.com/modelcontextprotocol)
