# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-12

### Added
- Initial release of Qwen3-VL MCP Server
- Support for all 9 Qwen3-VL API endpoints:
  - 2D Grounding (`qwen_vl_grounding_2d`)
  - Spatial Understanding (`qwen_vl_spatial_understanding`)
  - Video Understanding (`qwen_vl_video_understanding`)
  - Image Description (`qwen_vl_image_description`)
  - Document Parsing (`qwen_vl_document_parsing`)
  - Document OCR (`qwen_vl_document_ocr`)
  - Wild Image OCR (`qwen_vl_wild_image_ocr`)
  - Image Comparison (`qwen_vl_image_comparison`)
  - Health Check (`qwen_vl_health_check`)
- TypeScript implementation with full type safety
- Comprehensive documentation and examples
- Installation script for easy setup
- Claude Code integration support
- Configuration via environment variables
- Error handling and timeout management

### Documentation
- README.md with installation and usage instructions
- EXAMPLES.md with practical use cases
- API reference for all tools
- MCP configuration examples
- Troubleshooting guide

### Developer Experience
- TypeScript source code with strict typing
- Automatic build process
- Watch mode for development
- Clear project structure

## [Unreleased]

### Planned
- Batch processing support
- Streaming responses for large files
- Caching mechanism for frequently used images
- Rate limiting and retry logic
- Progress tracking for long-running operations
- Support for custom model configurations
- WebSocket support for real-time updates
- Metrics and monitoring integration
